<template>
  <div
    class="bg-ob-deep-800 p-4 mt-8 lg:px-14 lg:py-10 rounded-2xl shadow-xl mb-8 lg:mb-0"
  >
    <Title :title="'titles.comment'" paddings="pb-2 pt-0" />
    <div id="gitalk-container"></div>
    <div id="vcomments"></div>
    <div id="tcomment"></div>
    <div id="waline"></div>
  </div>
</template>

<script lang="ts">
import { useAppStore } from '@/stores/app'
import { defineComponent, onMounted, toRefs, watch } from 'vue'
import { Title } from '@/components/Title'
import { usePostStore } from '@/stores/post'
import { twikooInit } from '@/utils/comments/twikoo-api'
import { githubInit } from '@/utils/comments/github-api'
import { valineInit } from '@/utils/comments/valine-api'
import { walineInit } from '@/utils/comments/waline-api'

const languages: Record<string, string> = {
  en: 'en',
  cn: 'zh'
}

export default defineComponent({
  name: 'ObComment',
  props: {
    /** Used for create issue title by Gitalk */
    title: {
      type: String,
      default: ''
    },
    /** Used for create issue body content by Gitalk */
    body: {
      type: String,
      default: ''
    },
    /** Unique ID used by Gitalk and Valine */
    uid: {
      type: String,
      default: ''
    }
  },
  components: { Title },
  setup(props) {
    const postTitle = toRefs(props).title
    const postBody = toRefs(props).body
    const postUid = toRefs(props).uid
    const appStore = useAppStore()
    const postStore = usePostStore()
    let waline: any = undefined

    const enabledComment = (
      postTitle: string,
      postBody: string,
      postUid: string
    ) => {
      /**
       * Generate the data needed for Gitalk to generate the issue.
       */
      const title = !postTitle || postTitle === '' ? '' : postTitle
      const body =
        !postBody || postBody === ''
          ? window.location.href
          : `${window.location.href} \n ${postBody}`

      const uid =
        appStore.themeConfig.plugins.gitalk.id === 'pathname'
          ? window.location.pathname
          : postUid

      /**
       * Caching the current post data, used
       * when config changes on render updates.
       */
      postStore.setCache({
        title: postTitle,
        body: postBody,
        uid: postUid
      })

      if (!appStore.configReady) return

      if (appStore.themeConfig.plugins.gitalk.enable) {
        const proxy =
          appStore.themeConfig.plugins.gitalk.proxy === ''
            ? 'https://cors-anywhere.azm.workers.dev/https://github.com/login/oauth/access_token'
            : appStore.themeConfig.plugins.gitalk.proxy

        const { clientID, clientSecret, repo, owner, admin, language } =
          appStore.themeConfig.plugins.gitalk

        githubInit({
          clientID,
          clientSecret,
          repo,
          owner,
          admin,
          language,
          uid,
          title,
          body,
          proxy
        })
      } else if (appStore.themeConfig.plugins.valine.enable) {
        const {
          app_id,
          app_key,
          avatar,
          placeholder,
          visitor,
          lang,
          meta,
          requiredFields,
          avatarForce
        } = appStore.themeConfig.plugins.valine

        valineInit({
          appId: app_id,
          appKey: app_key,
          avatar,
          placeholder,
          visitor,
          lang,
          meta,
          requiredFields,
          avatarForce,
          path: window.location.pathname // Make sure updating pathname
        })
      } else if (appStore.themeConfig.plugins.twikoo.enable) {
        const { envId, region, lang } = appStore.themeConfig.plugins.twikoo
        twikooInit({ envId, region, lang, path: window.location.pathname })
      } else if (appStore.themeConfig.plugins.waline.enable) {
        const {
          serverURL,
          login,
          reaction,
          meta,
          requiredMeta,
          commentSorting,
          wordLimit,
          imageUploader,
          pageSize
        } = appStore.themeConfig.plugins.waline

        waline = walineInit({
          serverURL,
          lang: languages[appStore.locale ?? 'en'],
          login,
          reaction,
          meta,
          requiredMeta,
          commentSorting,
          wordLimit,
          imageUploader,
          pageSize
        })
      }
    }

    /** Wait for config is ready */
    watch(
      () => appStore.configReady,
      (newValue, oldValue) => {
        if (!oldValue && newValue) {
          const cachePost = postStore.cachePost
          enabledComment(cachePost.title, cachePost.body, cachePost.uid)
        }
      }
    )

    /** Updating comments base on current locale */
    watch(
      () => appStore.locale,
      (newLocale, oldLocale) => {
        if (waline && newLocale !== undefined && newLocale !== oldLocale) {
          waline.update({
            lang: languages[newLocale]
          })
        }
      }
    )

    onMounted(() => {
      enabledComment(postTitle.value, postBody.value, postUid.value)
    })
  }
})
</script>

<style lang="scss">
#vcomments {
  .vwrap {
    @apply rounded-xl bg-ob-deep-900;
    border: none;
    border-color: transparent;
    .vheader {
      @apply grid gap-2;
      &.item2 {
        @apply grid-cols-2;
      }
      &.item3 {
        @apply grid-cols-3;
      }
      .vinput {
        @apply bg-ob-deep-800 border-none w-full rounded-lg px-3;
      }
    }
  }
  .vcards {
    & > .vcard {
      @apply px-4 pt-6 pb-2 bg-ob-deep-900 mb-6 rounded-lg;
      transition: var(--trans-ease);
      &:hover {
        box-shadow: var(--accent-shadow);
      }
    }
    .vcard {
      .vimg {
        border: 2px solid var(--text-accent);
      }
      .vh {
        border: none;
        .vmeta .vat {
          color: var(--text-accent);
          opacity: 0.6;
          transition: var(--trans-ease);
          &:hover {
            opacity: 0.3;
          }
        }
      }
      .vquote {
        border: none;
      }
      .vhead {
        .vnick {
          color: var(--text-accent);
          font-weight: 700;
        }
      }
    }
  }
  .vbtn {
    background: var(--main-gradient);
    border: none;
    color: #fff;
    &:hover {
      color: #fff;
      opacity: 0.5;
    }
  }
  .vcount .vnum {
    color: var(--text-accent);
  }
  .veditor,
  .vinput {
    color: var(--text-normal);
  }
  .vicon {
    transition: var(--trans-ease);
    &:hover {
      opacity: 0.5;
    }
  }
  a {
    color: var(--text-sub-accent);
    transition: var(--trans-ease);
    &:hover {
      opacity: 0.5;
    }
  }
  blockquote {
    border-left: 0.25rem solid var(--bg-accent-55);
  }
  p {
    color: var(--text-normal);
  }
}

#gitalk-container {
  .gt-container {
    .gt-meta {
      border-bottom: 1px solid var(--background-primary);
    }
    .gt-header-textarea {
      background-color: var(--background-primary);
    }
    .gt-btn {
      border: none;
      background: var(--main-gradient);
      transition: var(--trans-ease);
      &:hover {
        opacity: 0.5;
      }
    }
    .gt-btn-preview {
      background: var(--background-secondary);
      color: var(--text-bright);
      opacity: 0.7;
    }
    .gt-header-controls-tip {
      color: var(--text-bright);
      opacity: 0.7;
      transition: var(--trans-ease);
      &:hover {
        opacity: 0.5;
      }
    }
    .gt-svg svg {
      fill: var(--text-bright);
    }
    .gt-popup {
      background: var(--background-secondary);
      border: 1px solid var(--background-primary);
      border-radius: 0.25rem;
    }
    .gt-copyright {
      border-top: 1px solid var(--background-primary);
    }
    .gt-link {
      border-bottom: 2px solid var(--text-accent);
    }
    a {
      color: var(--text-accent);
      transition: var(--trans-ease);
      &.is--active {
        color: var(--text-bright);
        &:before {
          background: var(--text-accent);
        }
      }
      &:hover {
        opacity: 0.5;
      }
    }
    .gt-comment-admin .gt-comment-content {
      background-color: var(--background-primary);
      box-shadow: var(--accent-shadow);
      &:hover {
        box-shadow: var(--accent-shadow);
      }
      a {
        color: var(--text-accent);
      }
      .gt-comment-body {
        &.markdown-body {
          blockquote {
            border-left: 0.25em solid var(--bg-accent-55);
          }
          pre {
            background-color: var(--background-secondary);
          }
        }
      }
    }
    .gt-comment-content {
      background-color: var(--background-primary);
      border-radius: 5px;
      &:hover {
        box-shadow: var(--sub-accent-shadow);
      }
      a {
        color: var(--text-sub-accent);
      }
    }
    .gt-comment-body {
      color: var(--text-normal) !important;
      &.markdown-body {
        blockquote {
          border-left: 0.25em solid var(--bg-sub-accent-55);
        }
      }
    }
  }
}

#twikoo {
  .tk-comments {
    @apply pt-2;
  }

  .tk-input {
    @apply bg-ob-deep-900;
  }

  .tk-meta-input input {
    @apply bg-ob-deep-900;
  }

  .el-input__inner:focus,
  .el-textarea__inner:focus {
    border-color: var(--text-accent);
  }

  .el-button--primary {
    background: var(--main-gradient);
    border: none;
    color: #fff;
    &:hover {
      color: #fff;
      opacity: 0.5;
    }
  }

  .tk-icon.__comments {
    color: var(--text-accent);
  }

  .tk-action-icon {
    color: var(--text-accent);
  }

  .tk-comment {
    @apply px-4 pt-6 pb-6 bg-ob-deep-900 mb-2 rounded-lg;
    transition: var(--trans-ease);
    &:hover {
      box-shadow: var(--accent-shadow);
    }
  }

  .tk-avatar {
    border: none;
  }

  .tk-nick {
    color: var(--text-accent);
    font-weight: 700;
  }

  .tk-comments-count {
    > span:first-of-type {
      color: var(--text-accent);
    }
  }
}

#waline {
  --waline-theme-color: var(--text-accent);
  --waline-border: var(--background-secondary);
  --waline-bgcolor: var(--background-primary);
  --waline-bgcolor-light: var(--background-secondary);
  --waline-badge-color: var(--text-accent);
  --waline-disabled-bgcolor: var(--text-dim);
  .wl-editor {
    @apply p-2 box-border;
  }

  .wl-login-nick,
  .wl-nick {
    color: var(--text-sub-accent);
  }

  .wl-card {
    @apply bg-ob-deep-900 p-4 rounded-lg;
  }

  .wl-num {
    color: var(--text-accent);
  }

  .primary.wl-btn {
    color: #fff;
    border: none;
    background: var(--main-gradient);
    transition: var(--trans-ease);
    &:hover {
      opacity: 0.5;
    }
  }

  .wl-card .wl-delete,
  .wl-card .wl-like,
  .wl-card .wl-reply,
  .wl-card .wl-edit {
    color: var(--text-dim);
  }

  .wl-card .wl-quote {
    border-inline-start: none;
  }

  .wl-header-item {
    @apply items-center;
  }

  .wl-header input {
    @apply p-2 m-2;
  }
}
</style>
