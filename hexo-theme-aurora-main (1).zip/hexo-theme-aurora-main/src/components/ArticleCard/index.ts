export { default as HorizontalArticle } from './src/HorizontalArticle.vue'
export { default as Article } from './src/Article.vue'
