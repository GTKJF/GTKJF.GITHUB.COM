export default {
  title: import.meta.env.VITE_APP_PROJECT_TITLE || 'TriDiamond Blog'
}
